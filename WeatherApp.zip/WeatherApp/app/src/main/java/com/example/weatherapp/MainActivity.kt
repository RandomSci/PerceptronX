package com.example.weatherapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.weatherapp.ui.theme.WeatherAppTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WeatherAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    WeatherApp()
                }
            }
        }
    }
}

@Composable
fun WeatherApp() {
    var currentWeather by remember { mutableStateOf("Sunny") }
    var currentTemp by remember { mutableIntStateOf(27) }
    var showForecast by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var useCelsius by remember { mutableStateOf(true) }

    val backgroundGradient = when (currentWeather) {
        "Sunny" -> Brush.verticalGradient(
            colors = listOf(
                Color(0xFF4B7BEC),
                Color(0xFF3867D6),
                Color(0xFF2F54EB)
            )
        )
        "Rainy" -> Brush.verticalGradient(
            colors = listOf(
                Color(0xFF546E7A),
                Color(0xFF455A64),
                Color(0xFF37474F)
            )
        )
        "Cloudy" -> Brush.verticalGradient(
            colors = listOf(
                Color(0xFF78909C),
                Color(0xFF607D8B),
                Color(0xFF546E7A)
            )
        )
        else -> Brush.verticalGradient(
            colors = listOf(
                Color(0xFF4B7BEC),
                Color(0xFF3867D6),
                Color(0xFF2F54EB)
            )
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(brush = backgroundGradient)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {

                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = Color.White,
                        modifier = Modifier
                            .size(28.dp)
                            .clickable { showMenu = true }
                            .background(Color.Transparent)
                    )

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier
                    ) {
                        DropdownMenuItem(
                            text = { Text("Wanna see a magic?", color = Color.White) },
                            onClick = { showMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("For you", color = Color.White) },
                            onClick = { showMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("More options", color = Color.White) },
                            onClick = { showMenu = false }
                        )
                    }
                }

                Text(
                    text = "Iloilo City, Iloilo",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )

                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = Color.White,
                    modifier = Modifier
                        .size(28.dp)
                        .clickable { showSettings = !showSettings }
                )
            }

            val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
            val currentDate = dateFormat.format(Date())

            Text(
                text = currentDate,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            Box(
                modifier = Modifier
                    .size(240.dp)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                when (currentWeather) {
                    "Sunny" -> {
                        AnimatedSun(modifier = Modifier.fillMaxSize())
                    }
                    "Rainy" -> {
                        AnimatedRain(modifier = Modifier.fillMaxSize())
                    }
                    "Cloudy" -> {
                        AnimatedClouds(modifier = Modifier.fillMaxSize())
                    }
                    else -> {
                        AnimatedSun(modifier = Modifier.fillMaxSize())
                    }
                }
            }

            val temperature = if (useCelsius) "$currentTemp°C" else "${(currentTemp * 9/5) + 32}°F"
            val scrollState = rememberScrollState()
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(16.dp)
            ) {
            Text(
                text = temperature,
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontSize = 64.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = Color.White
            )

            Text(
                text = currentWeather,
                style = MaterialTheme.typography.titleLarge,
                color = Color.White.copy(alpha = 0.9f),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            WeatherDetails()

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { showForecast = !showForecast },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White.copy(alpha = 0.2f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),

                shape = RoundedCornerShape(24.dp)
            ) {

                Text(
                    text = if (showForecast) "Hide Forecast" else "Show 5-Day Forecast",
                    color = Color.White,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            AnimatedVisibility(
                visible = showForecast,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                FiveDayForecast()
            }
        }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            WeatherTypeButton("Sunny", currentWeather == "Sunny") {
                currentWeather = "Sunny"
                currentTemp = 27
            }

            WeatherTypeButton("Cloudy", currentWeather == "Cloudy") {
                currentWeather = "Cloudy"
                currentTemp = 22
            }

            WeatherTypeButton("Rainy", currentWeather == "Rainy") {
                currentWeather = "Rainy"
                currentTemp = 18
            }
        }

        AnimatedVisibility(
            visible = showSettings,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 70.dp, end = 16.dp)
        ) {
            Card(
                modifier = Modifier
                    .width(200.dp)
                    .padding(8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White.copy(alpha = 0.8f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "Settings",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Temperature",
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Row {
                            Text(
                                text = "°C",
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .clickable { useCelsius = true }
                                    .background(if (useCelsius) Color(0xFF3867D6) else Color.Transparent)
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                color = if (useCelsius) Color.White else Color.Black
                            )

                            Text(
                                text = "°F",
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .clickable { useCelsius = false }
                                    .background(if (!useCelsius) Color(0xFF3867D6) else Color.Transparent)
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                color = if (!useCelsius) Color.White else Color.Black
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Notifications",
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Switch(
                            checked = true,
                            onCheckedChange = { /* Toggle notifications */ },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF3867D6),
                                checkedTrackColor = Color(0xFF3867D6).copy(alpha = 0.5f)
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WeatherTypeButton(type: String, isSelected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .padding(4.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected)
                Color.White.copy(alpha = 0.3f)
            else
                Color.White.copy(alpha = 0.1f)
        )
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val iconSize = 24.dp
            Box(
                modifier = Modifier.size(iconSize),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(iconSize)) {
                    when (type) {
                        "Sunny" -> {
                            drawCircle(
                                color = Color.White,
                                radius = size.minDimension / 2 * 0.7f
                            )
                        }
                        "Cloudy" -> {
                            val radius = size.minDimension / 5
                            drawCircle(
                                color = Color.White,
                                radius = radius,
                                center = Offset(size.width / 2, size.height / 2)
                            )
                            drawCircle(
                                color = Color.White,
                                radius = radius * 1.2f,
                                center = Offset(size.width / 2 - radius, size.height / 2 + radius * 0.5f)
                            )
                            drawCircle(
                                color = Color.White,
                                radius = radius * 1.1f,
                                center = Offset(size.width / 2 + radius, size.height / 2 + radius * 0.3f)
                            )
                        }
                        "Rainy" -> {
                            val centerX = size.width / 2
                            val centerY = size.height / 2
                            val radius = size.minDimension / 3

                            drawCircle(
                                color = Color.White,
                                radius = radius * 0.6f,
                                center = Offset(centerX, centerY - radius * 0.2f)
                            )

                            drawLine(
                                color = Color.White,
                                start = Offset(centerX, centerY + radius * 0.7f),
                                end = Offset(centerX, centerY - radius * 0.8f),
                                strokeWidth = radius * 0.8f,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }
            }

            Text(
                text = type,
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun WeatherDetails() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        WeatherDetailItem("💧", "Humidity", "68%")
        WeatherDetailItem("💨", "Wind", "12 km/h")
        WeatherDetailItem("☀️", "UV Index", "6")
    }
}

@Composable
fun WeatherDetailItem(icon: String, label: String, value: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = icon,
            fontSize = 24.sp,
            modifier = Modifier.padding(bottom = 4.dp)
        )

        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = 0.7f)
        )
    }
}

@Composable
fun FiveDayForecast() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.2f)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            val days = listOf("Today", "Wed", "Thu", "Fri", "Sat")
            val icons = listOf("☀️", "☁️", "🌧️", "☁️", "☀️")
            val temps = listOf("27°", "24°", "21°", "23°", "26°")

            days.forEachIndexed { index, day ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = day,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        modifier = Modifier.width(60.dp)
                    )

                    Text(
                        text = icons[index],
                        fontSize = 20.sp
                    )

                    Text(
                        text = temps[index],
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (index < days.size - 1) {
                    Divider(
                        color = Color.White.copy(alpha = 0.2f),
                        thickness = 1.dp
                    )
                }
            }
        }
    }
}

@Composable
fun AnimatedSun(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "")

    val sunOffsetY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 20f,
        animationSpec = infiniteRepeatable(
            tween(2000, easing = EaseInOutQuad),
            repeatMode = RepeatMode.Reverse
        ), label = ""
    )

    val rayScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = ""
    )

    Canvas(modifier = modifier) {
        val center = Offset(size.width / 2, size.height / 2 + sunOffsetY)
        val radius = size.minDimension * 0.25f

        // Sun core
        drawCircle(
            color = Color(0xFFFFD700),
            radius = radius,
            center = center
        )

        drawCircle(
            color = Color(0x40FFD700),
            radius = radius * 1.3f,
            center = center
        )

        val rayCount = 12
        val rayLength = radius * 0.8f * rayScale

        for (i in 0 until rayCount) {
            val angle = (i * (360f / rayCount)) * (Math.PI / 180f)
            val startX = center.x + cos(angle).toFloat() * (radius * 1.1f)
            val startY = center.y + sin(angle).toFloat() * (radius * 1.1f)
            val endX = center.x + cos(angle).toFloat() * (radius * 1.1f + rayLength)
            val endY = center.y + sin(angle).toFloat() * (radius * 1.1f + rayLength)

            drawLine(
                color = Color(0xFFFFD700),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 8f,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun AnimatedClouds(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "")

    val cloudOffset1 by infiniteTransition.animateFloat(
        initialValue = -30f,
        targetValue = 30f,
        animationSpec = infiniteRepeatable(
            tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ), label = ""
    )

    val cloudOffset2 by infiniteTransition.animateFloat(
        initialValue = 20f,
        targetValue = -20f,
        animationSpec = infiniteRepeatable(
            tween(5000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ), label = ""
    )

    Canvas(modifier = modifier) {
        // First
        val centerX1 = size.width * 0.5f + cloudOffset1
        val centerY1 = size.height * 0.4f

        drawCircle(color = Color.White, radius = size.minDimension * 0.12f, center = Offset(centerX1, centerY1))
        drawCircle(color = Color.White, radius = size.minDimension * 0.15f, center = Offset(centerX1 - size.minDimension * 0.13f, centerY1 + size.minDimension * 0.05f))
        drawCircle(color = Color.White, radius = size.minDimension * 0.14f, center = Offset(centerX1 + size.minDimension * 0.15f, centerY1 + size.minDimension * 0.03f))

        val centerX2 = size.width * 0.6f + cloudOffset2
        val centerY2 = size.height * 0.7f

        drawCircle(color = Color(0xDDEEEEEE), radius = size.minDimension * 0.1f, center = Offset(centerX2, centerY2))
        drawCircle(color = Color(0xDDEEEEEE), radius = size.minDimension * 0.13f, center = Offset(centerX2 - size.minDimension * 0.11f, centerY2 + size.minDimension * 0.04f))
        drawCircle(color = Color(0xDDEEEEEE), radius = size.minDimension * 0.12f, center = Offset(centerX2 + size.minDimension * 0.12f, centerY2 + size.minDimension * 0.02f))
    }
}

@Composable
fun AnimatedRain(modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val raindrops = remember { mutableStateListOf<Raindrop>() }
    val infiniteTransition = rememberInfiniteTransition(label = "")

    val cloudOffset by infiniteTransition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ), label = ""
    )

    LaunchedEffect(Unit) {
        scope.launch {
            while (true) {
                val newRaindrop = Raindrop(
                    x = (Math.random() * 0.8 + 0.1).toFloat(),
                    y = -0.1f,
                    speed = (Math.random() * 0.02 + 0.02).toFloat(),
                    length = (Math.random() * 0.05 + 0.05).toFloat()
                )
                raindrops.add(newRaindrop)

                if (raindrops.size > 100) {
                    raindrops.removeAt(0)
                }

                delay(50)
            }
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            raindrops.forEachIndexed { index, raindrop ->
                raindrops[index] = raindrop.copy(
                    y = raindrop.y + raindrop.speed
                )
            }
            delay(16) // ~60fps
        }
    }

    Canvas(modifier = modifier) {
        val centerX = size.width * 0.5f + cloudOffset
        val centerY = size.height * 0.3f

        drawCircle(color = Color(0xDDDDDDDD), radius = size.minDimension * 0.15f, center = Offset(centerX, centerY))
        drawCircle(color = Color(0xDDDDDDDD), radius = size.minDimension * 0.18f, center = Offset(centerX - size.minDimension * 0.16f, centerY + size.minDimension * 0.06f))
        drawCircle(color = Color(0xDDDDDDDD), radius = size.minDimension * 0.17f, center = Offset(centerX + size.minDimension * 0.18f, centerY + size.minDimension * 0.04f))

        raindrops.forEach { raindrop ->
            val startX = size.width * raindrop.x
            val startY = size.height * raindrop.y
            val endY = startY + size.height * raindrop.length

            drawLine(
                color = Color(0xBB4FC3F7),
                start = Offset(startX, startY),
                end = Offset(startX, endY),
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )
        }
    }
}

data class Raindrop(
    val x: Float,
    val y: Float,
    val speed: Float,
    val length: Float
)

@Preview(showBackground = true)
@Composable
fun WeatherAppPreview() {
    WeatherAppTheme {
        WeatherApp()
    }
}